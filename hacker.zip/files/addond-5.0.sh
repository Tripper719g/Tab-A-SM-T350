#!/sbin/sh
#
# This addon.d script was automatically generated
# It backs up the files installed by hacker.zip
# If there are any issues, send an email to admin@shadow53.com
# describing the issue
#

. /tmp/backuptool.functions

list_files() {
  cat <<EOF
app/Termux/Termux.apk
app/TermuxAPI/TermuxAPI.apk
app/TermuxStyling/TermuxStyling.apk
app/Termux/lib/arm64/libtermux.so
app/HackersKeyboard/lib/x86_64/libjni_pckeyboard.so
app/TermuxWidget/TermuxWidget.apk
app/Termux/lib/arm/libtermux.so
app/HackersKeyboard/lib/arm64/libjni_pckeyboard.so
app/Termux/lib/x86/libtermux.so
app/Termux/lib/x86_64/libtermux.so
etc/default-permissions/hacker-permissions.xml
app/HackersKeyboard/lib/arm/libjni_pckeyboard.so
app/HackersKeyboard/lib/x86/libjni_pckeyboard.so
app/HackersKeyboard/HackersKeyboard.apk

EOF
}

case "$1" in
  backup)
    list_files | while read FILE DUMMY; do
      echo "Backing up $FILE"
      backup_file $S/"$FILE"
    done
  ;;
  restore)
  list_files | while read FILE REPLACEMENT; do
    echo "Restoring $REPLACEMENT"
    R=""
    [ -n "$REPLACEMENT" ] && R="$S/$REPLACEMENT"
    [ -f "$C/$S/$FILE" ] && restore_file $S/"$FILE" "$R"
  done
  ;;
  pre-backup)
  #Stub
  ;;
  post-backup)
  #Stub
  ;;
  pre-restore)
  #Stub
  ;;
  post-restore)
  #Stub
  ;;
esac